// Jack XXI - Pure C++ DES + 3DES-EDE for Pafet's cipher stage.
//
// Mirrors scripts/pafet_des3_offline.py:
//   - des3_decrypt_ecb(data, key24) = D_K1( E_K2( D_K3(data) ) )
//   - decrypt_material(ciphertext, key) runs des3_decrypt_ecb three times,
//     applying a permissive unpad after each pass.
//   - unpad: if data[-1] in 1..8 and <= len, remove that many bytes.
//
// Standard FIPS 46-3 DES (ignores LSB of every key byte via PC-1).
// Public-domain style tables.

#pragma once
#include <cstdint>
#include <cstring>
#include <vector>

namespace pafet_des3_xxi {

// Initial permutation
static const uint8_t IP[64] = {
    58,50,42,34,26,18,10, 2, 60,52,44,36,28,20,12, 4,
    62,54,46,38,30,22,14, 6, 64,56,48,40,32,24,16, 8,
    57,49,41,33,25,17, 9, 1, 59,51,43,35,27,19,11, 3,
    61,53,45,37,29,21,13, 5, 63,55,47,39,31,23,15, 7
};
// Final permutation (inverse of IP)
static const uint8_t FP[64] = {
    40, 8,48,16,56,24,64,32, 39, 7,47,15,55,23,63,31,
    38, 6,46,14,54,22,62,30, 37, 5,45,13,53,21,61,29,
    36, 4,44,12,52,20,60,28, 35, 3,43,11,51,19,59,27,
    34, 2,42,10,50,18,58,26, 33, 1,41, 9,49,17,57,25
};
// Expansion E
static const uint8_t E[48] = {
    32, 1, 2, 3, 4, 5,  4, 5, 6, 7, 8, 9,
     8, 9,10,11,12,13, 12,13,14,15,16,17,
    16,17,18,19,20,21, 20,21,22,23,24,25,
    24,25,26,27,28,29, 28,29,30,31,32, 1
};
// P permutation
static const uint8_t P[32] = {
    16, 7,20,21,29,12,28,17, 1,15,23,26, 5,18,31,10,
     2, 8,24,14,32,27, 3, 9,19,13,30, 6,22,11, 4,25
};
// PC-1 for key schedule (56 bits from 64, dropping parity)
static const uint8_t PC1[56] = {
    57,49,41,33,25,17, 9,  1,58,50,42,34,26,18,
    10, 2,59,51,43,35,27, 19,11, 3,60,52,44,36,
    63,55,47,39,31,23,15,  7,62,54,46,38,30,22,
    14, 6,61,53,45,37,29, 21,13, 5,28,20,12, 4
};
// PC-2 for round subkeys
static const uint8_t PC2[48] = {
    14,17,11,24, 1, 5, 3,28,15, 6,21,10,
    23,19,12, 4,26, 8,16, 7,27,20,13, 2,
    41,52,31,37,47,55,30,40,51,45,33,48,
    44,49,39,56,34,53,46,42,50,36,29,32
};
// Rotation schedule per round
static const uint8_t ROT[16] = {1,1,2,2,2,2,2,2, 1,2,2,2,2,2,2,1};
// S-boxes
static const uint8_t SBOX[8][64] = {
    {14, 4,13, 1, 2,15,11, 8, 3,10, 6,12, 5, 9, 0, 7,
      0,15, 7, 4,14, 2,13, 1,10, 6,12,11, 9, 5, 3, 8,
      4, 1,14, 8,13, 6, 2,11,15,12, 9, 7, 3,10, 5, 0,
     15,12, 8, 2, 4, 9, 1, 7, 5,11, 3,14,10, 0, 6,13},
    {15, 1, 8,14, 6,11, 3, 4, 9, 7, 2,13,12, 0, 5,10,
      3,13, 4, 7,15, 2, 8,14,12, 0, 1,10, 6, 9,11, 5,
      0,14, 7,11,10, 4,13, 1, 5, 8,12, 6, 9, 3, 2,15,
     13, 8,10, 1, 3,15, 4, 2,11, 6, 7,12, 0, 5,14, 9},
    {10, 0, 9,14, 6, 3,15, 5, 1,13,12, 7,11, 4, 2, 8,
     13, 7, 0, 9, 3, 4, 6,10, 2, 8, 5,14,12,11,15, 1,
     13, 6, 4, 9, 8,15, 3, 0,11, 1, 2,12, 5,10,14, 7,
      1,10,13, 0, 6, 9, 8, 7, 4,15,14, 3,11, 5, 2,12},
    { 7,13,14, 3, 0, 6, 9,10, 1, 2, 8, 5,11,12, 4,15,
     13, 8,11, 5, 6,15, 0, 3, 4, 7, 2,12, 1,10,14, 9,
     10, 6, 9, 0,12,11, 7,13,15, 1, 3,14, 5, 2, 8, 4,
      3,15, 0, 6,10, 1,13, 8, 9, 4, 5,11,12, 7, 2,14},
    { 2,12, 4, 1, 7,10,11, 6, 8, 5, 3,15,13, 0,14, 9,
     14,11, 2,12, 4, 7,13, 1, 5, 0,15,10, 3, 9, 8, 6,
      4, 2, 1,11,10,13, 7, 8,15, 9,12, 5, 6, 3, 0,14,
     11, 8,12, 7, 1,14, 2,13, 6,15, 0, 9,10, 4, 5, 3},
    {12, 1,10,15, 9, 2, 6, 8, 0,13, 3, 4,14, 7, 5,11,
     10,15, 4, 2, 7,12, 9, 5, 6, 1,13,14, 0,11, 3, 8,
      9,14,15, 5, 2, 8,12, 3, 7, 0, 4,10, 1,13,11, 6,
      4, 3, 2,12, 9, 5,15,10,11,14, 1, 7, 6, 0, 8,13},
    { 4,11, 2,14,15, 0, 8,13, 3,12, 9, 7, 5,10, 6, 1,
     13, 0,11, 7, 4, 9, 1,10,14, 3, 5,12, 2,15, 8, 6,
      1, 4,11,13,12, 3, 7,14,10,15, 6, 8, 0, 5, 9, 2,
      6,11,13, 8, 1, 4,10, 7, 9, 5, 0,15,14, 2, 3,12},
    {13, 2, 8, 4, 6,15,11, 1,10, 9, 3,14, 5, 0,12, 7,
      1,15,13, 8,10, 3, 7, 4,12, 5, 6,11, 0,14, 9, 2,
      7,11, 4, 1, 9,12,14, 2, 0, 6,10,13,15, 3, 5, 8,
      2, 1,14, 7, 4,10, 8,13,15,12, 9, 0, 3, 5, 6,11}
};

// Get bit from byte-indexed 1-based (DES tables use 1-based indexing)
static inline uint64_t bits_from_bytes(const uint8_t* b, const uint8_t* table, int n) {
    uint64_t r = 0;
    for (int i = 0; i < n; i++) {
        int bitpos = table[i] - 1;        // 0-based
        int byte = bitpos >> 3;
        int bit = 7 - (bitpos & 7);
        r = (r << 1) | ((b[byte] >> bit) & 1);
    }
    return r;
}

// Pack `n` bits of value `v` (MSB first) into bytes
static inline void bytes_from_bits(uint64_t v, int n, uint8_t* out) {
    memset(out, 0, (n + 7) / 8);
    for (int i = 0; i < n; i++) {
        int bit = (int)((v >> (n - 1 - i)) & 1);
        out[i >> 3] |= (uint8_t)(bit << (7 - (i & 7)));
    }
}

// Permute an n-bit value `v` of width `in_bits` by `table` of `out_bits`
static inline uint64_t permute(uint64_t v, int in_bits, const uint8_t* table, int out_bits) {
    uint64_t r = 0;
    for (int i = 0; i < out_bits; i++) {
        int bitpos = table[i] - 1;             // 0-based from MSB of input
        int src_shift = (in_bits - 1) - bitpos;
        r = (r << 1) | ((v >> src_shift) & 1);
    }
    return r;
}

// Key schedule: 8-byte key -> 16 subkeys of 48 bits
static inline void key_schedule(const uint8_t key[8], uint64_t subkeys[16]) {
    // Load key as 64-bit
    uint64_t K = 0;
    for (int i = 0; i < 8; i++) K = (K << 8) | key[i];
    // PC-1 -> 56 bits
    uint64_t K56 = permute(K, 64, PC1, 56);
    uint32_t C = (uint32_t)((K56 >> 28) & 0x0FFFFFFF);
    uint32_t D = (uint32_t)(K56 & 0x0FFFFFFF);
    for (int r = 0; r < 16; r++) {
        int s = ROT[r];
        C = ((C << s) | (C >> (28 - s))) & 0x0FFFFFFF;
        D = ((D << s) | (D >> (28 - s))) & 0x0FFFFFFF;
        uint64_t CD = ((uint64_t)C << 28) | D;
        subkeys[r] = permute(CD, 56, PC2, 48);
    }
}

// F function
static inline uint32_t F(uint32_t R, uint64_t subkey) {
    uint64_t ER = permute(R, 32, E, 48);
    uint64_t x = ER ^ subkey;
    uint32_t out = 0;
    for (int i = 0; i < 8; i++) {
        uint8_t six = (uint8_t)((x >> (42 - i * 6)) & 0x3F);
        int row = ((six & 0x20) >> 4) | (six & 0x01);
        int col = (six >> 1) & 0x0F;
        out = (out << 4) | SBOX[i][row * 16 + col];
    }
    return (uint32_t)permute(out, 32, P, 32);
}

// Encrypt one 8-byte block with 16 subkeys (encrypt or decrypt depending on
// subkey order).
static inline void des_block(const uint8_t in[8], uint8_t out[8], const uint64_t subkeys[16], bool encrypt) {
    uint64_t X = 0;
    for (int i = 0; i < 8; i++) X = (X << 8) | in[i];
    uint64_t P = permute(X, 64, IP, 64);
    uint32_t L = (uint32_t)((P >> 32) & 0xFFFFFFFF);
    uint32_t R = (uint32_t)(P & 0xFFFFFFFF);
    for (int r = 0; r < 16; r++) {
        int kidx = encrypt ? r : (15 - r);
        uint32_t newL = R;
        uint32_t newR = L ^ F(R, subkeys[kidx]);
        L = newL; R = newR;
    }
    // Final swap: pre-image is R || L (not L || R)
    uint64_t RL = ((uint64_t)R << 32) | L;
    uint64_t Y = permute(RL, 64, FP, 64);
    for (int i = 0; i < 8; i++) out[i] = (uint8_t)((Y >> (56 - i * 8)) & 0xFF);
}

inline void des_encrypt_block(const uint8_t key[8], const uint8_t in[8], uint8_t out[8]) {
    uint64_t sk[16]; key_schedule(key, sk); des_block(in, out, sk, true);
}
inline void des_decrypt_block(const uint8_t key[8], const uint8_t in[8], uint8_t out[8]) {
    uint64_t sk[16]; key_schedule(key, sk); des_block(in, out, sk, false);
}

// ECB mode over multiple 8-byte blocks.
inline void des_ecb_enc(const uint8_t key[8], const uint8_t* in, size_t len, uint8_t* out) {
    uint64_t sk[16]; key_schedule(key, sk);
    for (size_t i = 0; i < len; i += 8) des_block(in + i, out + i, sk, true);
}
inline void des_ecb_dec(const uint8_t key[8], const uint8_t* in, size_t len, uint8_t* out) {
    uint64_t sk[16]; key_schedule(key, sk);
    for (size_t i = 0; i < len; i += 8) des_block(in + i, out + i, sk, false);
}

// 3DES-EDE decrypt (as Python oracle does):
//   out = D_K1( E_K2( D_K3( data ) ) )
inline void des3_decrypt_ecb(const uint8_t key24[24], const uint8_t* in, size_t len, uint8_t* out) {
    const uint8_t* K1 = key24;
    const uint8_t* K2 = key24 + 8;
    const uint8_t* K3 = key24 + 16;
    std::vector<uint8_t> tmp1(len), tmp2(len);
    des_ecb_dec(K3, in,          len, tmp1.data());
    des_ecb_enc(K2, tmp1.data(), len, tmp2.data());
    des_ecb_dec(K1, tmp2.data(), len, out);
}

// Permissive unpad: if last byte in 1..8 and <= len, remove that many bytes.
inline std::vector<uint8_t> unpad(const std::vector<uint8_t>& data) {
    if (!data.empty()) {
        uint8_t last = data.back();
        if (last >= 1 && last <= 8 && last <= data.size()) {
            return std::vector<uint8_t>(data.begin(), data.end() - last);
        }
    }
    return data;
}

// 3 passes with unpad between, returning the last stage. Stops with empty
// vector if an intermediate trim leaves a partial block.
inline std::vector<uint8_t> decrypt_material(const uint8_t ct[72], const uint8_t key24[24]) {
    std::vector<uint8_t> data(ct, ct + 72);
    for (int pass = 0; pass < 3; pass++) {
        if (data.size() % 8 != 0) return {};  // partial block guard
        std::vector<uint8_t> tmp(data.size());
        des3_decrypt_ecb(key24, data.data(), data.size(), tmp.data());
        data = unpad(tmp);
    }
    return data;
}

} // namespace pafet_des3_xxi
