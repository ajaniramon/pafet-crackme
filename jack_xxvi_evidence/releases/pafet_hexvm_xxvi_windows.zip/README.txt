JACK XXVI - literal Hex-VM executor for Windows x64

Run in PowerShell from this extracted folder:
  .\pafet_hexvm_xxvi.exe original_mapped_image.bin deadbeef

The output contains decoded bytes, the 128-byte virtual register file and
execution counters. Python, Frida, Unicorn and WSL are not runtime dependencies.
The data image supplies the original tables; its native code is never called.

This is the complete literal C++ executor, including initialization and cleanup.
The separate small semantic core remains partial. Validation is a finite corpus,
not a proof for every seed, branch or OS failure. See the included report.
